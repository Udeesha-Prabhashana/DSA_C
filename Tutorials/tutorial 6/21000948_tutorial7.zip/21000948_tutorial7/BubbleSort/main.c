#include <stdio.h>
#include <stdlib.h>
//swap-function-----------
void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

//------------------------

//Bubble-sort
void bubbleSort(int arr[],int size)
{
    for(int step=size-2;step>=0;step--)
    {
      for(int i=0;i<=step;i++)
      {
          if(arr[i]>arr[i+1])
          {
              int temp=arr[i+1];
              arr[i+1]=arr[i];
              arr[i]=temp;
          }
        }
    }
}
//--------------

//----Print-array---------------
void printArr(int arr[],int size)
{
   for(int i=0;i<size;i++)
   {
       printf(" %d",arr[i]);
   }
}
int main()
{
    printf("Unsorted array: \n");
    int arr[]={1,5,8,6,7,9,4,45,67,12};
    int size=sizeof(arr)/sizeof(arr[0]);
    printArr(arr,size);
    printf("\n");
    bubbleSort(arr,size);
    printf("Sorted array: \n");
    printArr(arr,size);
    printf("\n");
}
