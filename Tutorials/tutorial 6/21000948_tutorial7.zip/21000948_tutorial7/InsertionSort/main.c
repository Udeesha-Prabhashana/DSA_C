#include <stdio.h>
#include <stdlib.h>
//swap-function-----------
void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

//------------------------

//Insertion-sort---------------------
void insertionSort(int arr[],int size)
{
    for(int step=1;step<size;step++)
    {
        int key=step;
        while(arr[key]<arr[key-1] && key>0)
        {
            swap(&arr[key],&arr[key-1]);
            key--;
        }
    }
}


//--------------

//----Print-array---------------
void printArr(int arr[],int size)
{
   for(int i=0;i<size;i++)
   {
       printf(" %d",arr[i]);
   }
}
int main()
{
    printf("Unsorted array: \n");
    int arr[]={1,5,8,6,7,9,4,45,67,12};
    int size=sizeof(arr)/sizeof(arr[0]);
    printArr(arr,size);
    printf("\n");
    insertionSort(arr,size);
    printf("Sorted array: \n");
    printArr(arr,size);
    printf("\n");
}
