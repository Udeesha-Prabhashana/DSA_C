#include <stdio.h>
#include <stdlib.h>
//swap-function-----------
void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

//------------------------

//Selection-sort---------------------
void selectionSort(int arr[],int size)
{
    for(int step=0;step<size-1;step++)
    {
        int min=step;
        for(int i=step+1;i<size;i++)
        {
            if(arr[i]<arr[min])
            {
                min=i;
            }
        }
        swap(&arr[min],&arr[step]);
    }
}


//--------------

//----Print-array---------------
void printArr(int arr[],int size)
{
   for(int i=0;i<size;i++)
   {
       printf(" %d",arr[i]);
   }
}
int main()
{
    printf("Unsorted array: \n");
    int arr[]={1,5,8,6,7,9,4,45,67,12};
    int size=sizeof(arr)/sizeof(arr[0]);
    printArr(arr,size);
    printf("\n");
    selectionSort(arr,size);
    printf("Sorted array: \n");
    printArr(arr,size);
    printf("\n");
}
